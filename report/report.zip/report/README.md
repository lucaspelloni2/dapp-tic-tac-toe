We've used this for about a half-dozen Ph. D. dissertations. The current files pass the format requirements 
in spring 2013.

Please contribute your own corrections. By sharing this we are making things easier for all students using 
LaTeX for the dissertations at ASU.

To see an example of a dissertation formatted using these LaTeX style files, 
click [here](http://www.public.asu.edu/~jelynn/dis.pdf).

Feel free to email john.shumwayjr@gmail.com if you are a graduating ASU student with LaTeX questions.

